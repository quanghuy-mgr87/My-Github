﻿using System;

namespace SalesManagement.Model.Entity.Disp
{
    public class CalcAggregation
    {
        public DateTime? SaleDateTime { get; set; }
        public int Price { get; set; }
    }
}
