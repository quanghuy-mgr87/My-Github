﻿using System.Windows.Forms;

namespace SalesManagement
{
    // データ削除確認　フォームクラス
    public partial class DeleteConfirmForm : Form
    {
        public DeleteConfirmForm()
        {
            InitializeComponent();
        }
    }
}
