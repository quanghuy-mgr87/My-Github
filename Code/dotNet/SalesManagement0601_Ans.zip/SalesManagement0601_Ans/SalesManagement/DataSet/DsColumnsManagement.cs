﻿namespace SalesManagement.DataSet
{


    partial class DsColumnsManagement
    {
    }
}
