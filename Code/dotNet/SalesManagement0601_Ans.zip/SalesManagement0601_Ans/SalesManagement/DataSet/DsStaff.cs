﻿namespace SalesManagement.DataSet
{


    partial class DsStaff
    {
    }
}

namespace SalesManagement.DataSet.DsStaffTableAdapters {
    
    
    public partial class M_StaffTableAdapter {
    }
}

namespace SalesManagement.DataSet.DsStaffTableAdapters
{


    public partial class M_StaffTableAdapter
    {
    }
}
