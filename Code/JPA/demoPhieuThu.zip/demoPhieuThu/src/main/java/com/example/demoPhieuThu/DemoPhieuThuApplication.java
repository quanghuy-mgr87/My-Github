package com.example.demoPhieuThu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPhieuThuApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPhieuThuApplication.class, args);
	}

}
