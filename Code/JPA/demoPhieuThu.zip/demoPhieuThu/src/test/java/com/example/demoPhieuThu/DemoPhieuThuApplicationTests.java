package com.example.demoPhieuThu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPhieuThuApplicationTests {

	@Test
	void contextLoads() {
	}

}
