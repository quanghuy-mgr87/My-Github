package com.example.DemoJPABuoi1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpaBuoi1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJpaBuoi1Application.class, args);
	}

}
