package com.example.DemoJPABuoi1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJpaBuoi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
