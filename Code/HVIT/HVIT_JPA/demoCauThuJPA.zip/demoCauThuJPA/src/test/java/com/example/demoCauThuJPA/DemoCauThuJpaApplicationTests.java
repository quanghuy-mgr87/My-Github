package com.example.demoCauThuJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCauThuJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
