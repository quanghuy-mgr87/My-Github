package com.example.demoCauThuJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCauThuJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoCauThuJpaApplication.class, args);
	}

}
