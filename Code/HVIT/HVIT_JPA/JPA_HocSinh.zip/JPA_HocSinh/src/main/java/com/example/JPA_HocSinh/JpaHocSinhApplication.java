package com.example.JPA_HocSinh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaHocSinhApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaHocSinhApplication.class, args);
	}

}
